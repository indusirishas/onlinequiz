package com.capgemini.universityadmission.exception;

public interface IExceptionMessages {

	String MESSAGE1 = "Property File not found...!!";
	String MESSAGE2 = "Driver Class not found..!!";
	String MESSAGE3 = "Problem in reading property..!!";
	String MESSAGE4 = "Problem in obtaining connection..!!";
	String MESSAGE5 = "Programs offered are not available";
	String MESSAGE6 = "Scheduled Programs are not available";
	String MESSAGE7 = "Applicants details cannot be inserted";
	String MESSAGE8 = "Applicant ID Sequence cannot be generated";
	String MESSAGE9 = "Login credentials are not found..!";
	String MESSAGE10 = "The applicants details cannot be generated for the given program name..!";
	String MESSAGE11 = "Cannot retrieve the status of the applicants..!";
	String MESSAGE12 = "Application Status cannot be updated..!";
	String MESSAGE13 = "The applicants details cannot be generated..!";
	String MESSAGE14 = "Participants details cannot be added..!";
	String MESSAGE15 = "The programs scheduled cannot be deleted..!";
	String MESSAGE16 = "The entered details cannot be inserted into programs_scheduled...!";
	String MESSAGE17 = "The participants details cannot be generated..!";
	String MESSAGE18 = "The program scheduled cannot be deleted for the given program ID..!";

}
