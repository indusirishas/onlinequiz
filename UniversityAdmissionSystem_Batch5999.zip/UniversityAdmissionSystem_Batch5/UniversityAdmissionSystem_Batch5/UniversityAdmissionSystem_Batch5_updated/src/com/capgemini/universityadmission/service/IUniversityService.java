package com.capgemini.universityadmission.service;

import java.util.ArrayList;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;

public interface IUniversityService {
	public ArrayList<ProgramsOffered> viewAllPrograms() throws UASException;

	public ArrayList<ProgramsScheduled> viewScheduledPrograms()
			throws UASException;

	public Integer applicantDetails(Application application)
			throws UASException;

	public boolean adminLogin(String userName, String password, String role)
			throws UASException;

	public Application applicantStatus(Integer id) throws UASException;

	public Integer addParticipants(Application application) throws UASException;

	public ArrayList<Application> filterApplicantsByProgramName(String progName)
			throws UASException;

	public Integer deletePrograms() throws UASException;

	public Integer insertProgram(ProgramsScheduled programsScheduled)
			throws UASException;

	public Integer updateStatus(Integer applicantId, Integer marksObtained)
			throws UASException;

	public ArrayList<Participants> retrieveParticipants() throws UASException;
	
	public Integer removeProgramsScheduled(String scheduledId) throws UASException;
}
