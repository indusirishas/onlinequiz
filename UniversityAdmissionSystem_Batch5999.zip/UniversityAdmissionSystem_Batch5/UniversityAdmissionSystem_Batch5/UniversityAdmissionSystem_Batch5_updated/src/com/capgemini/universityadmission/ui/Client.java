package com.capgemini.universityadmission.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.IExceptionMessages;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;

public class Client {
	public static void main(String[] args) {
		try {
			System.out
					.println("**********************************************************");
			System.out
					.println("*             UNIVERSITY ADMISSION SYSTEM                *");
			System.out
					.println("**********************************************************");
			IUniversityService service = new UniversityServiceImpl();
			int choice = -1;
			System.out
					.println("----------------------------------------------------------------------------------------------------------");
			System.out.println("**********************");
			System.out.println("***Programs Offered***");
			System.out.println("**********************");
			ArrayList<ProgramsOffered> list = new ArrayList<>();
			list = service.viewAllPrograms();
			if (list.isEmpty()) {
				throw new UASException(IExceptionMessages.MESSAGE8);
			}
			System.out.printf("%10s %20s %20s %10s %20s", "PROGRAM_NAME",
					"PROGRAM_DESCRIPTION", "APPLICANT_ELIGIBILITY", "DURATION",
					"DEGREE_CERT_OFFERED");
			System.out.println();
			for (ProgramsOffered po : list) {
				System.out.format("%10s %20s %20s %10s %20s",
						po.getProgramName(), po.getProgramDescription(),
						po.getApplicantEligibility(), po.getProgramDuration(),
						po.getDegreeCertOffered());
				System.out.println();
			}
			System.out
					.println("----------------------------------------------------------------------------------------------------------");
			do {
				System.out
						.println("1.View Scheduled Programs\n2.Register to a Program\n3.Applicant Status\n4.Login as Admin\n5.Exit");
				Scanner scanner = new Scanner(System.in);
				choice = scanner.nextInt();
				switch (choice) {
				case 1:

					System.out.println();
					System.out.println("************************");
					System.out.println("***Scheduled Programs***");
					System.out.println("************************");
					ArrayList<ProgramsScheduled> list1 = new ArrayList<>();
					list1 = service.viewScheduledPrograms();
					if (list1.isEmpty()) {
						throw new UASException(IExceptionMessages.MESSAGE7);
					}
					System.out.printf("%15s %10s %10s %17s %19s %12s",
							"SCHEDULE_PROG_ID", "PROGRAM_NAME", "LOCATION",
							"START_DATE", "END_DATE", "SESSIONS_PER_WEEK");
					System.out.println();
					for (ProgramsScheduled ps : list1) {
						System.out.format("%15s %10s %10s %20s %20s %10s",
								ps.getScheduledProgramId(),
								ps.getProgramName(), ps.getLocation(),
								ps.getStartDate(), ps.getEndDate(),
								ps.getSessionsPerWeek());
						System.out.println();
					}
					System.out
							.println("----------------------------------------------------------------------------------------------------------");
					break;
				case 2:
					Scanner scanner2 = new Scanner(System.in);
					Application application = new Application();
					System.out.println("Enter Full Name");
					String fullName = scanner2.nextLine();
					application.setFullName(fullName);
					System.out.println("Enter Date Of Birth");
					String dateOfBirth = scanner2.nextLine();
					LocalDate ld;
					DateTimeFormatter formatter = DateTimeFormatter
							.ofPattern("dd/MM/yyyy");
					ld = LocalDate.parse(dateOfBirth, formatter);
					application.setDateOfBirth(ld);
					System.out.println("Enter highest Qualification");
					String highestQualification = scanner2.nextLine();
					application.setHighestQualification(highestQualification);
					System.out.println("Enter Goals");
					String goals = scanner2.nextLine();
					application.setGoals(goals);
					System.out.println("Enter Email ID");
					String emailId = scanner2.nextLine();
					application.setEmailId(emailId);
					System.out.println("Enter Program Scheduled ID");
					String scheduledId = scanner2.nextLine();
					application.setScheduledProgramId(scheduledId);
					System.out.println("Enter Marks Obtained");
					Integer marksObtained = scanner2.nextInt();
					application.setMarksObtained(marksObtained);
					int regApplicantId = service.applicantDetails(application);
					if (regApplicantId != 0) {
						System.out.println("Registered Successfully");
						System.out.println("Your applicantId is "
								+ regApplicantId);
					} else
						System.out
								.println("Not Registered Successfully. Please try again..!!!");
					break;
				case 3:
					System.out.println("Please enter your ApplicantID");
					Scanner scanner1 = new Scanner(System.in);
					Integer applicantId = scanner1.nextInt();
					Application application1 = new Application();
					application1 = service.applicantStatus(applicantId);
					if (application1.getStatus().equalsIgnoreCase("confirmed")) {
						System.out.println("Your application status is "
								+ application1.getStatus().toUpperCase()
								+ " and your interview is scheduled on "
								+ application1.getDateOfInterview());
					} else {
						System.out.println("Your application status is "
								+ application1.getStatus().toUpperCase());
					}
					break;
				case 4:
					Scanner scanner3 = new Scanner(System.in);
					String role = null;
					Integer ch = -1;
					loginBlock: do {
						Scanner scanner4 = new Scanner(System.in);
						System.out
								.println("1.Login as mac\n2.Login as admin\n3.Exit");
						System.out.println("Enter your choice");
						Integer ch1 = scanner4.nextInt();
						switch (ch1) {
						case 1:
							System.out.println("Enter UserName");
							String userName = scanner3.next();
							System.out.println("Enter Password");
							String password = scanner3.next();
							System.out.println("Choose your role(mac/admin)");
							role = scanner3.next().toLowerCase();
							if (!role.equalsIgnoreCase("mac")
									&& !role.equalsIgnoreCase("admin") /*
																		 * &&
																		 * !role
																		 * .
																		 * equalsIgnoreCase
																		 * (
																		 * "exit"
																		 * )
																		 */) {
								System.out
										.println("Please enter your role as mac/admin");
							}
							boolean authorised = service.adminLogin(userName,
									password, role);
							if (authorised) {
								macblock: do {
									System.out
											.println("1.Filter and update the status of the applicants");
									System.out
											.println("2.Enter details of participant ");
									System.out
											.println("3.View participants\n4.exit");
									System.out.println("Choose your choice");
									ch = scanner3.nextInt();
									switch (ch) {
									case 1:
										System.out
												.println("Enter program name");
										Scanner sc = new Scanner(System.in);
										String progName = sc.next();
										System.out.printf(
												"%15s %20s %20s %20s",
												"APPLICANT_ID", "FULL_NAME",
												"MARKS_OBTAINED",
												"QUALIFICATION");
										System.out.println();
										ArrayList<Application> list3 = new ArrayList<>();
										list3 = service
												.filterApplicantsByProgramName(progName);
										if (list3.isEmpty()) {
											throw new UASException(
													IExceptionMessages.MESSAGE9);
										}
										for (Application a : list3) {
											System.out
													.format("%15s %20s %20s %20s",
															a.getApplicantId(),
															a.getFullName(),
															a.getMarksObtained(),
															a.getHighestQualification());
											System.out.println();
										}
										for (Application b : list3) {
											if (service.updateStatus(
													b.getApplicantId(),
													b.getMarksObtained()) == 1) {
												System.out.println(b
														.getApplicantId()
														+ " is updated");
											} else {
												System.out.println(b
														.getApplicantId()
														+ " is not updated");
											}
										}
										break;
									case 2:
										Application application2 = new Application();
										if (service
												.addParticipants(application2) == 1) {
											System.out
													.println("Participants added");
										} else {
											throw new UASException(
													IExceptionMessages.MESSAGE6);
										}
										break;
									case 3:
										ArrayList<Participants> list2 = new ArrayList<>();
										list2 = service.retrieveParticipants();
										if (list2.isEmpty()) {
											throw new UASException(
													IExceptionMessages.MESSAGE10);
										}
										for (Participants p : list2) {
											System.out
													.println(p.getRollNo()
															+ " "
															+ p.getApplicantId()
															+ " "
															+ p.getEmailId()
															+ " "
															+ p.getScheduledProgramId());
										}
										break;
									case 4:
										break macblock;
									}
								} while (ch != 0);
							} else {
								System.out.println("Not Authorised");
							}
							break;
						case 2:
							System.out.println("Enter UserName");
							String userName1 = scanner3.next();
							System.out.println("Enter Password");
							String password2 = scanner3.next();
							System.out.println("Choose your role(mac/admin)");
							role = scanner3.next().toLowerCase();
							if (!role.equalsIgnoreCase("mac")
									&& !role.equalsIgnoreCase("admin") /*
																		 * &&
																		 * !role
																		 * .
																		 * equalsIgnoreCase
																		 * (
																		 * "exit"
																		 * )
																		 */) {
								System.out
										.println("Please enter your role as mac/admin");
							}
							boolean authorised1 = service.adminLogin(userName1,
									password2, role);
							if (authorised1) {
								adminblock: do {
									System.out.println("1.Insert programs");
									System.out
											.println("2.Delete programs\n3.View Participants\n4.exit");
									System.out.println("Choose your choice");
									ch = scanner3.nextInt();
									switch (ch) {
									case 1:
										ProgramsScheduled programsScheduled = new ProgramsScheduled();
										System.out.println("Enter program id");
										String scheduledProgramId = scanner3
												.next();
										programsScheduled
												.setScheduledProgramId(scheduledProgramId);
										System.out
												.println("Enter program name");
										String programName = scanner3.next();
										programsScheduled
												.setProgramName(programName);
										System.out.println("Enter location");
										String location = scanner3.next();
										programsScheduled.setLocation(location);
										System.out.println("Enter start date");
										String sdate = scanner3.next();
										LocalDate startDate = null;
										DateTimeFormatter formatter1 = DateTimeFormatter
												.ofPattern("dd/MM/yyyy");
										startDate = LocalDate.parse(sdate,
												formatter1);
										programsScheduled
												.setStartDate(startDate);
										System.out.println("Enter end date");
										String edate = scanner3.next();
										LocalDate endDate = null;
										DateTimeFormatter formatter2 = DateTimeFormatter
												.ofPattern("dd/MM/yyyy");
										endDate = LocalDate.parse(edate,
												formatter2);
										programsScheduled.setEndDate(endDate);
										System.out
												.println("Enter sessions per week");
										Integer sessionsPerWeek = scanner3
												.nextInt();
										programsScheduled
												.setSessionsPerWeek(sessionsPerWeek);
										if (service
												.insertProgram(programsScheduled) == 1)
											System.out
													.println("Program added successfully");
										else
											System.out
													.println("Not added successfully");
										break;
									case 2:
										System.out
												.println("Enter the Scheduled Program ID");
										String prgScheduledId = scanner3.next();
										if (service
												.removeProgramsScheduled(prgScheduledId) == 1) {
											System.out
													.println("Deleted Successfully");
										} else {
											System.out.println("Not Deleted");
										}
										break;
									case 3:
										ArrayList<Participants> list2 = new ArrayList<>();
										list2 = service.retrieveParticipants();
										if (list2.isEmpty()) {
											throw new UASException(
													IExceptionMessages.MESSAGE10);
										}
										for (Participants p : list2) {
											System.out
													.println(p.getRollNo()
															+ " "
															+ p.getApplicantId()
															+ " "
															+ p.getEmailId()
															+ " "
															+ p.getScheduledProgramId());
										}
										break;
									case 4:
										break adminblock;
									}

								} while (ch != 0);
							} else {
								System.out.println("Not authorised");
							}
							break;
						case 3:
							break loginBlock;
						}
					} while (role != null);
					break;
				case 5:
					System.out.println("Thank You...!!");
					System.exit(0);
					break;
				}
			} while (choice != 0);
		} catch (UASException e) {
			System.out.println(e.getMessage());
		}
	}
}
