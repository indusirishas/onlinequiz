package com.capgemini.universityadmission.junit;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.Test;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;

public class UniversityServiceImplTest {

	public UniversityServiceImplTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*@Test
	public void testApplicantDetails() throws UASException {
		IUniversityService service = new UniversityServiceImpl();
		Application application = new Application();
		application.setFullName("Pranay Naredla");
		String dateOfBirth = "25/02/1997";
		LocalDate ld;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ld = LocalDate.parse(dateOfBirth, formatter);
		application.setDateOfBirth(ld);
		application.setHighestQualification("B Tech");
		application.setMarksObtained(72);
		application.setGoals("S/W H/W");
		application.setEmailId("pn@g.com");
		application.setScheduledProgramId("102");
		application.setStatus("accepted");
		int i = service.applicantDetails(application);
		assertEquals(1062, i);
	}*/
	@Test
	public void testProgramScheduled() throws UASException{
		IUniversityService service=new UniversityServiceImpl();
		ArrayList<ProgramsScheduled> list=service.viewScheduledPrograms();
		assertEquals("104", list.get(3).getScheduledProgramId());
		assertEquals("Hyderabad", list.get(3).getLocation());
	}
	
	/*@Test
	public void testMemberOfAdmin() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String progName="JAVA";
		ArrayList<Application> list = service.memberOfAdmin(progName); 
		assertEquals(1041, list.get(0).getApplicantId());
		
	}*/
	
	@Test
	public void testAdminLogin() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String userName="admin";
		String password ="admin";
		String role = "admin";
		boolean result = service.adminLogin(userName, password, role);
		assertEquals(true, result);
	}
	
	@Test
	public void testApplicantStatus() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		Integer id = 0;
		Application application = service.applicantStatus(id);
		assertEquals("confirmed", application.getStatus());
	}
	
	@Test
	public void testUpdateStatus() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		Integer applicantId=1061;
		Integer marksObtained=80;
		int result = service.updateStatus(applicantId, marksObtained);
		assertEquals(1, result);
	}
	
	@Test
	public void testAddParticipants() throws UASException{
		//fill this if needed
	}
	
	@Test
	public void testDeletePrograms() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		int result = service.deletePrograms();
		assertEquals(1, result);
	}
	
	@Test
	public void testInsertProgram() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		
		String sd = "28/04/2017";
		LocalDate startDate;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		startDate = LocalDate.parse(sd, formatter);
		
		String ed = "16/08/2017";
		LocalDate endDate;
		endDate = LocalDate.parse(ed, formatter);
		
		ProgramsScheduled programsScheduled = new ProgramsScheduled();
		programsScheduled.setScheduledProgramId("123");
		programsScheduled.setProgramName("JAVA");
		programsScheduled.setLocation("Chennai");
		programsScheduled.setStartDate(startDate);
		programsScheduled.setEndDate(endDate);
		programsScheduled.setSessionsPerWeek(4);
		int result = service.insertProgram(programsScheduled);
		assertEquals(1, result);
	}
	
	@Test
	public void testRemoveProgramsScheduled() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String scheduledId = "101";
		int result = service.removeProgramsScheduled(scheduledId);
		assertEquals(1, result);	
	}
	
	@Test
	public void testViewAllPrograms() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<ProgramsOffered> list = service.viewAllPrograms();
		assertEquals(".NET", list.get(2).getProgramName());
	}
	
	@Test
	public void testRetrieveParticipants() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<Participants> list = service.retrieveParticipants();
		assertEquals("53", list.get(0).getRollNo());
	}

}
