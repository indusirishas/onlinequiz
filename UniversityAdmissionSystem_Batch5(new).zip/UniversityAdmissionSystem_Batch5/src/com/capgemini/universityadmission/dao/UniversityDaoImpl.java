package com.capgemini.universityadmission.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsOffered;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.IExceptionMessages;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.util.DBUtil;

public class UniversityDaoImpl implements IUniversityDao {

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) 
	 * METHOD NAME: viewAllPrograms()
	 * PARAMETERS : No Parameters RETURN TYPE: ArrayList<ProgramsOffered>
	 * DESCRIPTION: Retrieving all the programs offered by the University
	 *******************************************************************************************************************/
	@Override
	public ArrayList<ProgramsOffered> viewAllPrograms() throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<ProgramsOffered> programsoffered = new ArrayList<>();
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY1);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst()) {
				throw new UASException(IExceptionMessages.MESSAGE5);
			}
			while (resultSet.next()) {
				ProgramsOffered offered = new ProgramsOffered();
				offered.setProgramName(resultSet.getString(1));
				offered.setProgramDescription(resultSet.getString(2));
				offered.setApplicantEligibility(resultSet.getString(3));
				offered.setProgramDuration(resultSet.getInt(4));
				offered.setDegreeCertOffered(resultSet.getString(5));
				programsoffered.add(offered);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return programsoffered;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: viewScheduledPrograms()
	 * PARAMETERS : No Parameters RETURN TYPE: ArrayList<ProgramsScheduled>
	 * DESCRIPTION: Retrieving all the programs scheduled by the University
	 *******************************************************************************************************************/
	@Override
	public ArrayList<ProgramsScheduled> viewScheduledPrograms()
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<ProgramsScheduled> programsScheduledList = new ArrayList<>();
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY2);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst()) {
				throw new UASException(IExceptionMessages.MESSAGE6);
			}
			while (resultSet.next()) {
				ProgramsScheduled programsScheduled = new ProgramsScheduled();
				programsScheduled.setScheduledProgramId(resultSet.getString(1));
				programsScheduled.setProgramName(resultSet.getString(2));
				programsScheduled.setLocation(resultSet.getString(3));
				programsScheduled.setStartDate(resultSet.getDate(4)
						.toLocalDate());
				programsScheduled
						.setEndDate(resultSet.getDate(5).toLocalDate());
				programsScheduled.setSessionsPerWeek(resultSet.getInt(6));
				programsScheduledList.add(programsScheduled);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return programsScheduledList;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: applicantDetails()
	 * PARAMETERS : Application RETURN TYPE: Integer DESCRIPTION: Stores
	 * applicant details in database and returns applicant id to applicant
	 *******************************************************************************************************************/
	@Override
	public Integer applicantDetails(Application application)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int result = 0;
		int applicantid = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY3);
			preparedStatement.setString(1, application.getFullName());
			preparedStatement.setDate(2,
					Date.valueOf(application.getDateOfBirth()));
			preparedStatement.setString(3,
					application.getHighestQualification());
			preparedStatement.setInt(4, application.getMarksObtained());
			preparedStatement.setString(5, application.getGoals());
			preparedStatement.setString(6, application.getEmailId());
			preparedStatement.setString(7, application.getScheduledProgramId());
			preparedStatement.setString(8, "applied");
			result = preparedStatement.executeUpdate();
			if (result == 0) {
				throw new UASException(IExceptionMessages.MESSAGE7);
			}
			if (result == 1) {
				preparedStatement = connection
						.prepareStatement(IQueryMapper.QUERY15);
				resultSet = preparedStatement.executeQuery();
				if (!resultSet.isBeforeFirst())
					throw new UASException(IExceptionMessages.MESSAGE8);
				if (resultSet.next()) {
					applicantid = resultSet.getInt(1);
				}
			}
		} catch (SQLException e) {

			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return applicantid;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: adminLogin() PARAMETERS
	 * : userName, password, role RETURN TYPE: boolean DESCRIPTION: To
	 * authenticate admin or mac credentials
	 *******************************************************************************************************************/
	@Override
	public boolean adminLogin(String userName, String password, String role)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean result = false;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY4);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst())
				throw new UASException(IExceptionMessages.MESSAGE9);
			while (resultSet.next()) {
				if (resultSet.getString(1).equals(userName)
						&& resultSet.getString(2).equals(password)
						&& resultSet.getString(3).equals(role)) {
					System.out.println();
					System.out.println("AUTHENTICATED USER");
					System.out.println();
					result = true;
				}
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME:
	 * filterApplicantsByProgramName() PARAMETERS : program name RETURN TYPE:
	 * ArrayList<Application> DESCRIPTION: Retrieving all the applicants based
	 * on the program name given by mac
	 *******************************************************************************************************************/
	@Override
	public ArrayList<Application> filterApplicantsByProgramName(String progName)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<Application> list = new ArrayList<>();
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY5);
			preparedStatement.setString(1, progName);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst())
				throw new UASException(IExceptionMessages.MESSAGE10);
			while (resultSet.next()) {
				Application application = new Application();
				application.setApplicantId(resultSet.getInt(1));
				application.setFullName(resultSet.getString(2));
				application.setMarksObtained(resultSet.getInt(3));
				application.setHighestQualification(resultSet.getString(4));
				list.add(application);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return list;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: applicantStatus()
	 * PARAMETERS : Id RETURN TYPE: Application DESCRIPTION: Retrieving the
	 * Status of the applicant based on the given applicant id and returns date
	 * of interview if Confirmed
	 *******************************************************************************************************************/
	@Override
	public Application applicantStatus(Integer id) throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Application application = new Application();
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY6);
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst())
				throw new UASException(IExceptionMessages.MESSAGE11);
			if (resultSet.next()) {
				application.setStatus(resultSet.getString(1));
				application.setDateOfInterview(resultSet.getDate(2)
						.toLocalDate());
				// statusId = resultSet.getString(1);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return application;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: updateStatus()
	 * PARAMETERS : applicant id, marks obtained RETURN TYPE: Integer
	 * DESCRIPTION: Updates the status to confirmed or rejected based on marks
	 * obtained by mac
	 *******************************************************************************************************************/
	@Override
	public Integer updateStatus(Integer applicantId, Integer marksObtained)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			if (marksObtained > 65) {
				Random random = new Random();
				int min = 2;
				int max = 5;
				int randVal = random.nextInt((max - min) + 1) + min;
				preparedStatement = connection
						.prepareStatement(IQueryMapper.QUERY7);
				preparedStatement.setString(1, "accepted");
				preparedStatement.setInt(2, randVal);
				preparedStatement.setInt(3, applicantId);
				result = preparedStatement.executeUpdate();
				if (result == 0) {
					throw new UASException(IExceptionMessages.MESSAGE12);
				}
			} else {
				preparedStatement = connection
						.prepareStatement(IQueryMapper.QUERY12);
				preparedStatement.setString(1, "rejected");
				preparedStatement.setInt(2, applicantId);
				result = preparedStatement.executeUpdate();
				if (result == 0) {
					throw new UASException(IExceptionMessages.MESSAGE12);
				}
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: addParticipants()
	 * PARAMETERS : Application RETURN TYPE: Integer DESCRIPTION: Adding the
	 * participants to participants table based on their status
	 *******************************************************************************************************************/
	@Override
	public Integer addParticipants(Application application) throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		String emailId = null;
		Integer applicantId = 0;
		String scheduledProgId = null;
		ResultSet resultSet = null;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY9);
			preparedStatement.setString(1, "confirmed");
			resultSet = preparedStatement.executeQuery();
			/*
			 * if (!resultSet.isBeforeFirst()) throw new
			 * UASException(IExceptionMessages.MESSAGE13);
			 */
			while (resultSet.next()) {
				emailId = resultSet.getString("email_id");
				applicantId = resultSet.getInt("applicant_id");
				scheduledProgId = resultSet.getString("scheduled_program_id");
				preparedStatement = connection
						.prepareStatement(IQueryMapper.QUERY8);
				preparedStatement.setString(1, emailId);
				preparedStatement.setInt(2, applicantId);
				preparedStatement.setString(3, scheduledProgId);
				result = preparedStatement.executeUpdate();
			}
			/*
			 * if(result!=1) { throw new
			 * UASException(IExceptionMessages.MESSAGE14); }
			 */
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: deletePrograms()
	 * PARAMETERS : No Parameters RETURN TYPE: Integer DESCRIPTION: Removes the
	 * scheduled program if the scheduled date is expired
	 *******************************************************************************************************************/
	@Override
	public Integer deletePrograms() throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY10);
			result = preparedStatement.executeUpdate();
			/*
			 * if(result==0) { throw new
			 * UASException(IExceptionMessages.MESSAGE15); }
			 */
		} catch (SQLException e) {

			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: insertProgram()
	 * PARAMETERS : ProgramsScheduled RETURN TYPE: Integer DESCRIPTION: Admin
	 * inserts new programs into the database
	 *******************************************************************************************************************/
	@Override
	public Integer insertProgram(ProgramsScheduled programsScheduled)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY11);
			preparedStatement.setString(1,
					programsScheduled.getScheduledProgramId());
			preparedStatement.setString(2, programsScheduled.getProgramName());
			preparedStatement.setString(3, programsScheduled.getLocation());
			preparedStatement.setDate(4,
					Date.valueOf(programsScheduled.getStartDate()));
			preparedStatement.setDate(5,
					Date.valueOf(programsScheduled.getEndDate()));
			preparedStatement.setInt(6, programsScheduled.getSessionsPerWeek());
			result = preparedStatement.executeUpdate();
			if (result == 0) {
				throw new UASException(IExceptionMessages.MESSAGE16);
			}
		} catch (SQLException e) {

			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: retrieveParticipants()
	 * PARAMETERS : No Parameters RETURN TYPE: ArrayList<Participants>
	 * DESCRIPTION: Retrieving all the participants registered for the scheduled
	 * program
	 *******************************************************************************************************************/
	@Override
	public ArrayList<Participants> retrieveParticipants() throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<Participants> participantsList = new ArrayList<>();
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY13);
			resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst())
				throw new UASException(IExceptionMessages.MESSAGE17);
			while (resultSet.next()) {
				Participants participants = new Participants();
				participants.setRollNo(resultSet.getString("roll_no"));
				participants.setEmailId(resultSet.getString("email_id"));
				participants.setApplicantId(resultSet.getInt("applicant_id"));
				participants.setScheduledProgramId(resultSet
						.getString("scheduled_program_id"));
				participantsList.add(participants);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return participantsList;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME:
	 * removeProgramsScheduled() PARAMETERS : schedule id RETURN TYPE: Integer
	 * DESCRIPTION: Admin removes scheduled programs from the database
	 *******************************************************************************************************************/
	@Override
	public Integer removeProgramsScheduled(String scheduledId)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY14);
			preparedStatement.setString(1, scheduledId);
			result = preparedStatement.executeUpdate();
			if (result == 0) {
				throw new UASException(IExceptionMessages.MESSAGE18);
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: checkScheduledId()
	 * PARAMETERS : schedule id RETURN TYPE: boolean DESCRIPTION: Checking the
	 * entered scheduled Id is valid
	 *******************************************************************************************************************/
	@Override
	public boolean checkScheduledId(String scheduledId) throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean result = true;
		int flag = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY16);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				if (resultSet.getString(1).equals(scheduledId)) {
					flag = 1;
					break;
				}
			}
			if (flag == 1) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	/******************************************************************************************************************
	 * AUTHOR NAME: JEE_BATCH-5(Capgemini) METHOD NAME: checkApplicantId()
	 * PARAMETERS : schedule id RETURN TYPE: Integer DESCRIPTION: Checking the
	 * entered Applicant Id is valid
	 *******************************************************************************************************************/
	@Override
	public boolean checkApplicantId(Integer applicantId) throws UASException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean result = true;
		int flag = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY17);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				if (resultSet.getInt(1) == applicantId) {
					flag = 1;
					break;
				}
			}
			if (flag == 1) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	@Override
	public Integer confirmParticipants(Integer applicantId, String status)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;

		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY18);
			preparedStatement.setString(1, status);
			preparedStatement.setString(2, "accepted");
			preparedStatement.setInt(3, applicantId);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	@Override
	public Integer addProgramsOffered(ProgramsOffered programsOffered)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY18);
			preparedStatement.setString(1, programsOffered.getProgramName());
			preparedStatement.setString(2,
					programsOffered.getProgramDescription());
			preparedStatement.setString(3,
					programsOffered.getApplicantEligibility());
			preparedStatement.setInt(4, programsOffered.getProgramDuration());
			preparedStatement.setString(5,
					programsOffered.getDegreeCertOffered());
			result = preparedStatement.executeUpdate();
		} catch (Exception e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}

	@Override
	public Integer deleteProgramsOffered(String programName1)
			throws UASException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY19);
			preparedStatement.setString(1, programName1);
			result = preparedStatement.executeUpdate();
		} catch (Exception e) {
			throw new UASException(IExceptionMessages.MESSAGE4);
		}
		return result;
	}
}
