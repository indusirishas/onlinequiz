package com.capgemini.universityadmission.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.universityadmission.exception.IExceptionMessages;
import com.capgemini.universityadmission.exception.UASException;

public class DBUtil {
	private static Connection connection=null;
	public static Connection getConnection() throws UASException{
		if(connection==null){
			try {
				FileInputStream fin = new FileInputStream("resources/JDBC.properties");
				Properties props = new Properties();
				props.load(fin);			
				String driver = props.getProperty("db.driver");
				String url = props.getProperty("db.url");
				String user = props.getProperty("db.user");
				String pass = props.getProperty("db.pass");
				Class.forName(driver);
				connection = DriverManager.getConnection(url, user, pass);
				connection.commit();
			} catch (FileNotFoundException e) {
				throw new UASException(IExceptionMessages.MESSAGE1);
			} catch (ClassNotFoundException e) {
				throw new UASException(IExceptionMessages.MESSAGE2);
			} catch (IOException e) {
				throw new UASException(IExceptionMessages.MESSAGE3);
			} catch (SQLException e) {
				throw new UASException(IExceptionMessages.MESSAGE4);
			}	
		}
		return connection;
	}
}
