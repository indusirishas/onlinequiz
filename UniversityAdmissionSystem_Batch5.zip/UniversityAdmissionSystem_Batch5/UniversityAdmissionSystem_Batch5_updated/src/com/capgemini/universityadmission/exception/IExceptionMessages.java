package com.capgemini.universityadmission.exception;

public interface IExceptionMessages {

	String MESSAGE1 = "Property File not found...!!";
	String MESSAGE2 = "Driver Class not found..!!";
	String MESSAGE3 = "Problem in reading property..!!";
	String MESSAGE4 = "Problem in obtaining connection..!!";
	String MESSAGE5 = "Data not available...!!";
	String MESSAGE6 = "Participants details cannot be added..!";
	String MESSAGE7 = "Scheduled Programs are not available";
	String MESSAGE8 = "Programs offered are not available";
	/*String MESSAGE9 = "No data available to filter and update the status";
	String MESSAGE10 = "No participants available";*/
	String MESSAGE11 = "Sequence Value cannot be generated";
	String MESSAGE12 = "Login credentials cannot be found";
	String MESSAGE13 = "The applicants details cannot be generated for the given program name";
	String MESSAGE14 = "Cannot retrieve the status of the applicants";
	String MESSAGE15 = "Application Status cannot be updated";
	String MESSAGE16 = "The applicants details cannot be generated";
	String MESSAGE17 = "The programs scheduled cannot be deleted";
	String MESSAGE18 = "Details cannot be inserted into programs_scheduled";
	String MESSAGE19 = "The participants details cannot be generated";
	String MESSAGE20 = "The program scheduled cannot be deleted for the given program ID";

}
