package com.capgemini.universityadmission.junit;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.Test;

import com.capgemini.universityadmission.bean.Application;
import com.capgemini.universityadmission.bean.Participants;
import com.capgemini.universityadmission.bean.ProgramsScheduled;
import com.capgemini.universityadmission.exception.UASException;
import com.capgemini.universityadmission.service.IUniversityService;
import com.capgemini.universityadmission.service.UniversityServiceImpl;

public class UniversityServiceImplTest {

	public UniversityServiceImplTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*@Test
	public void testApplicantDetails() throws UASException {
		IUniversityService service = new UniversityServiceImpl();
		Application application = new Application();
		application.setFullName("Pranay Naredla");
		String dateOfBirth = "25/02/1997";
		LocalDate ld;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ld = LocalDate.parse(dateOfBirth, formatter);
		application.setDateOfBirth(ld);
		application.setHighestQualification("B Tech");
		application.setMarksObtained(72);
		application.setGoals("S/W H/W");
		application.setEmailId("pn@g.com");
		application.setScheduledProgramId("102");
		application.setStatus("accepted");
		int i = service.applicantDetails(application);
		assertEquals(1045, i);
	}
	@Test
	public void testProgramScheduled() throws UASException{
		IUniversityService service=new UniversityServiceImpl();
		ArrayList<ProgramsScheduled> list=service.viewScheduledPrograms();
		assertEquals("104", list.get(3).getScheduledProgramId());
		assertEquals("Hyderabad", list.get(3).getLocation());
	}*/
	
	@Test
	public void testMemberOfAdmin() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		String progName="JAVA";
		ArrayList<Application> list = service.memberOfAdmin(progName); 
		assertEquals(1041,list.get(0).getApplicantId());
		
	}
	public void testApplicantDetails(){
		IUniversityService service = new UniversityServiceImpl();
		
		
	}
	
	/*@Test
	public void testViewAllPrograms() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<ProgramsOffered> list = service.viewAllPrograms();
		assertEquals(".NET", list.get(2).getProgramName());
	}
	
	@Test
	public void testRetrieveParticipants() throws UASException{
		IUniversityService service = new UniversityServiceImpl();
		ArrayList<Participants> list = service.retrieveParticipants();
		assertEquals("53", list.get(0).getRollNo());
	}*/

}
