package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.client.Employee;
import com.cg.service.IEmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	IEmployeeService service;
	
	@RequestMapping("/home")
	public String getHomePage()
	{
		String page=null;
		page="login";
		return page;
	}
	
	@RequestMapping("add.obj")
	public String displayAddPage(Model m)
	{
		Employee employee = new Employee();
		ArrayList<String> domain = new ArrayList<String>();
		domain.add("JEE");
		domain.add("VNV");
		domain.add(".NET");
		domain.add("ORAPPS");
		m.addAttribute("domains",domain);
		m.addAttribute("employee", employee);
		return "add";
	}

	@RequestMapping("back.obj")
	public String getBackPage(Model m)
	{
		String page=null;
		page="tms";
		return page;
	}
	
	@RequestMapping("delete.obj")
	public String getDeletePage(Model m)
	{
		String page=null;
		Employee employee = new Employee();
		page="delete";
		m.addAttribute("employee", employee);
		return page;
	}
	
	@RequestMapping("modify.obj")
	public String getModifyPage(Model m)
	{
		String page=null;
		Employee employee = new Employee();
		page="modify";
		m.addAttribute("employee", employee);
		return page;
	}
	
	@RequestMapping("retrieve.obj")
	public String getRetrievePage(Model m)
	{
		String page=null;
		Employee employee = new Employee();
		page="retrieve";
		m.addAttribute("employee", employee);
		return page;
	}
	@RequestMapping(value="Validatelogin.obj", method=RequestMethod.POST)
	public String checkLogin(@RequestParam String uname, @RequestParam String pwd,Model m)
	{
		System.out.println("Password="+pwd);
		System.out.println("Root="+uname);
		String page="";
		if("admin".equals(uname) && "root".equals(pwd))
		{
			System.out.println("Login Successful");
			page="tms";
		}
		else
		{
			String msg ="Please enter correct username and password";
			m.addAttribute("msg",msg);
			page="login";
		}
		return page;
	}
	
	
	@RequestMapping("addTrainee.obj")
	public String addTrainee(@ModelAttribute("employee") @Valid Employee employee, BindingResult bindingResult, Model m)
	{
		String page="";
		if(bindingResult.hasErrors())
		{
			ArrayList<String> domain = new ArrayList<String>();
			domain.add("JEE");
			domain.add("VNV");
			domain.add(".NET");
			domain.add("ORAPPS");
			m.addAttribute("domains",domain);
			page="add";
		}
		else
		{
			Employee emp = new Employee();
			emp = service.addEmployee(employee);
			m.addAttribute("emp", emp);
			page = "success";
			System.out.println(employee);
		}
		return page;
	}	
	
	
	@RequestMapping("deleteTrainee.obj")
	public String deleteTrainee(@ModelAttribute("employee") @Valid Employee employee, BindingResult bindingResult, Model m,@RequestParam String action)
	{
				String page="delete";	
				String message= "";
				if(action.equals("Check"))
				{
					Employee emp = new Employee();
					emp = service.checkEmployee(employee.getId());
					if(emp==null)
					{
						System.out.println("In if --");
						message="Please enter valid ID";
						m.addAttribute("msg",message);
					}
					else
					{
						m.addAttribute("emp", emp);
					}
				}
				else if(action.equals("DELETE"))
				{
					service.deleteEmployee(employee);
				}
			return page;
	}
	
	@RequestMapping("modifyTrainee.obj")
	public String modifyTrainee(@ModelAttribute("employee") @Valid Employee employee, BindingResult bindingResult, Model m, @RequestParam String action)
	{
			String page="modify";
			if(action.equals("Check"))
			{
				Employee emp = new Employee();
				emp = service.checkEmployee(employee.getTraineeId());
				if(emp==null)
				{
					String message="Please enter valid ID";
					m.addAttribute("message",message);
				}
				else
				{
					m.addAttribute("emp", emp);
				}
			}
			else if(action.equals("UPDATE"))
			{
				service.updateEmployee(employee);
			}
		return page;
	}
	
	@RequestMapping("retrieveTrainee.obj")
	public String retrieveTrainee(@ModelAttribute("employee") @Valid Employee employee, BindingResult bindingResult, Model m, @RequestParam String action)
	{
			String page="retrieve";
				Employee emp = new Employee();
				emp = service.checkEmployee(employee.getId());
				if(emp==null)
				{
					String message="Please enter valid ID";
					m.addAttribute("message",message);
				}
				else
				{
					m.addAttribute("emp", emp);
				}
		return page;
	}
	
}
