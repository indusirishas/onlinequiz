package com.cg.dao;

import com.cg.client.Employee;

public interface IEmployeeDao {

	public Employee addEmployee(Employee employee);
	public Employee checkEmployee(int id);
	public Employee deleteEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
}
