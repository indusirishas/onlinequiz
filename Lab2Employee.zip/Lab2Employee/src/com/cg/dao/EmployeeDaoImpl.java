package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.client.Employee;

@Repository("dao")
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public Employee addEmployee(Employee employee) {
		entityManager.persist(employee);
		entityManager.flush();
		return employee;
	}
	
	public Employee checkEmployee(int id){
		Employee emp = entityManager.find(Employee.class,id);
		return emp;
	}

	public Employee deleteEmployee(Employee employee) {		
		Employee emp = entityManager.find(Employee.class,employee.getId());
		entityManager.remove(emp);
		return emp;
	}


	public Employee updateEmployee(Employee employee) {
		entityManager.merge(employee);
		return employee;
	}

	
}
