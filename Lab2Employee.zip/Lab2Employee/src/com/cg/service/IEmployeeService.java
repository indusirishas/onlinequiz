package com.cg.service;

import com.cg.client.Employee;

public interface IEmployeeService {
	
	public Employee addEmployee(Employee employee);
	public Employee checkEmployee(int id);
	public Employee deleteEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
}
