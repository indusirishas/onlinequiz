package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.Employee;
import com.cg.dao.IEmployeeDao;
@Service("service")
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	IEmployeeDao dao;
	
	public Employee addEmployee(Employee employee) {
		return dao.addEmployee(employee);
	}
	
	public Employee checkEmployee(int id)
	{
		return dao.checkEmployee(id);
	}

	public Employee deleteEmployee(Employee employee) {
		return dao.deleteEmployee(employee);
	}


	public Employee updateEmployee(Employee employee) {
		return dao.updateEmployee(employee);
	}

}
