package com.cg.client;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@NotNull(message="Please enter trainee ID.... It is a required field")
	@Column(name="trainee_id")
	private Integer traineeId;
	
	@NotBlank(message="Please enter trainee Name.... It is a required field")
	@Column(name="trainee_name")
	private String traineeName;
	
	@NotBlank(message="Please enter trainee Location.... It is a required field")
	@Column(name="trainee_location")
	private String traineeLocation;
	
	@NotBlank(message="Please enter trainee Domain.... It is a required field")
	@Column(name="trainee_domain")
	private String traineeDomain;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", traineeId=" + traineeId
				+ ", traineeName=" + traineeName + ", traineeLocation="
				+ traineeLocation + ", traineeDomain=" + traineeDomain + "]";
	}
	
}
