package com.cg.bean;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
@Entity
@Table(name="faculty")
@NamedQuery(name="viewAllPlans",query="Select f from Faculty f")
public class Faculty 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="planid")
	private int id;
	
	@NotBlank(message="Plese enter name... This is a required field")
	@Column(name="fname")
	private String fname=null;
	
	@Column(name="plan_date")
	private LocalDate date=  null;
	
	@NotBlank(message="Plese enter subject... This is a required field")
	@Column(name="subject")
	private String subject = null;
	
	@NotBlank(message="Plese enter period... This is a required field")
	@Column(name="period")
	private String period = null;
	
	@NotBlank(message="Plese enter comments... This is a required field")
	@Column(name="comments")
	private String comments = null;
	
	@Email(message="Please enter valid MAIL id")
	@NotBlank(message="Plese enter name... This is a required field")
	@Column(name="mailid")
	private String mail = null;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public Faculty() {
		super();
	}
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", fname=" + fname + ", date=" + date
				+ ", subject=" + subject + ", period=" + period + ", comments="
				+ comments + ", mail=" + mail + "]";
	}
	
	
	
	
}
