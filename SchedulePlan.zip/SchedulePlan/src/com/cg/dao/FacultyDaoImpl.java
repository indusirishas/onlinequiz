package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.cg.bean.Faculty;

@Repository("dao")
@Transactional
public class FacultyDaoImpl implements IFacultyDao
{
	@PersistenceContext
	private EntityManager entityManager;
	public Faculty addFaculty(Faculty faculty) 
	{
		entityManager.persist(faculty);
		entityManager.flush();
		return faculty;
	}
	@Override
	public List<Faculty> getAllPlans() {
		
		System.out.println("In getAllPlans");
		String str = "Select f from Faculty f";
		TypedQuery<Faculty> query = entityManager.createQuery(str,Faculty.class);
		return query.getResultList();
	}
	public List<Faculty> getPlanById(Integer id)
	{
		System.out.println("In get Plan by Id");
		String str = "Select f from Faculty f where planid =:pid";
		TypedQuery<Faculty> query = entityManager.createQuery(str,Faculty.class);
		query.setParameter("pid", id);
		return query.getResultList();
		
	}
}
