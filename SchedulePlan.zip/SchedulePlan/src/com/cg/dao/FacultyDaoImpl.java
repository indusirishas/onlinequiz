package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Faculty;

@Repository("dao")
@Transactional
public class FacultyDaoImpl implements IFacultyDao
{
	@PersistenceContext
	private EntityManager entityManager;
	public Faculty addFaculty(Faculty faculty) 
	{
		entityManager.persist(faculty);
		entityManager.flush();
		return faculty;
	}
}
