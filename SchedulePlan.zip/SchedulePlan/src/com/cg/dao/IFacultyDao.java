package com.cg.dao;

import java.util.List;

import com.cg.bean.Faculty;

public interface IFacultyDao {
	public Faculty addFaculty(Faculty faculty);

	public List<Faculty> getAllPlans();
	public List<Faculty> getPlanById(Integer pid);
}
