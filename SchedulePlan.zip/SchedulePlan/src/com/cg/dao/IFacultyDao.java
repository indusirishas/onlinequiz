package com.cg.dao;


import com.cg.bean.Faculty;

public interface IFacultyDao {
	public Faculty addFaculty(Faculty faculty);
}
