package com.cg.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Faculty;
import com.cg.service.IFacultyService;

@Controller
public class MyController {
	
	@Autowired
	IFacultyService service;

	@RequestMapping("home.obj")
	public String getHomePage()
	{
		String page = "homepage";
		return page;
	}
	
	@RequestMapping("enterPlan.obj")
	public String getPlanPage(Model m)
	{
		String page = "enterPlan";
		LocalDate date = LocalDate.now();
		ArrayList<String> subjects = new ArrayList<String>();
		subjects.add("Maths");
		subjects.add("Physics");
		subjects.add("Chemistry");
		subjects.add("Biology");
		subjects.add("English");
		Faculty faculty = new Faculty();
		m.addAttribute("faculty", faculty);
		m.addAttribute("subjects", subjects);
		m.addAttribute("date", date);
		return page;
	}
	@RequestMapping("viewPlanById.obj")
	public String getPlanById(Model m)
	{
		return "viewPlanById";
	}
	@RequestMapping("getPlanById.obj")
	public String getPlanById(Model m,@RequestParam String id)
	{
		String page="";
		String msg ="";
		System.out.println("In view Plan by id");
		Integer pid = Integer.parseInt(id);
		List<Faculty> plans = service.getPlanById(pid);
		if(plans.isEmpty())
		{
			msg="Not Found!!";
			m.addAttribute("msg", msg);
			page="viewPlanById";
		}
		else
		{
		System.out.println("Plans="+plans);
		m.addAttribute("plans", plans);
		msg =""+plans;
		m.addAttribute("msg", msg);
		page= "viewPlanById";
		}
		return page;
	
	}
	
	@RequestMapping("getPlanDetails.obj")
	public String storeDetails(@ModelAttribute(value="faculty") @Valid Faculty faculty, BindingResult bindingResult, Model m)
	{
			String page = "success";
			if(bindingResult.hasErrors())
			{
				ArrayList<String> subjects = new ArrayList<String>();
				subjects.add("Maths");
				subjects.add("Physics");
				subjects.add("Chemistry");
				subjects.add("Biology");
				subjects.add("English");
				m.addAttribute("subjects", subjects);
				page="enterPlan";
			}
			else
			{
				System.out.println("-------plan ID = ---------"+faculty.getId());
				Faculty obj = service.addFaculty(faculty);
				System.out.println("Return value="+obj);
				m.addAttribute("bean", obj);
				m.addAttribute("id", faculty.getId());
				page = "success";
			
			}
			return page;
	}
	@RequestMapping("viewAllPlans.obj")
	public String getAllPlans(Model m)
	{
		String page="viewAllPlans";
		List<Faculty> plans = service.getAllPlans();
		m.addAttribute("plans", plans);
		return page;
	}
	
}
