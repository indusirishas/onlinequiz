package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Faculty;
import com.cg.service.IFacultyService;

@Controller
public class MyController {
	
	@Autowired
	IFacultyService service;

	@RequestMapping("home.obj")
	public String getHomePage()
	{
		String page = "homepage";
		return page;
	}
	
	@RequestMapping("enterPlan.obj")
	public String getPlanPage(Model m)
	{
		String page = "enterPlan";
		long millis =System.currentTimeMillis();
		java.util.Date date = new java.util.Date(millis);
		m.addAttribute("date", date);
		ArrayList<String> subjects = new ArrayList<String>();
		subjects.add("Maths");
		subjects.add("Physics");
		subjects.add("Chemistry");
		subjects.add("Biology");
		subjects.add("English");
		Faculty faculty = new Faculty();
		m.addAttribute("faculty", faculty);
		m.addAttribute("subjects", subjects);
		return page;
	}
	@RequestMapping("getPlanDetails.obj")
	public String storeDetails(@ModelAttribute(value="faculty") @Valid Faculty faculty, BindingResult bindingResult, Model m)
	{
			String page = "success";
			if(bindingResult.hasErrors())
			{
				ArrayList<String> subjects = new ArrayList<String>();
				subjects.add("Maths");
				subjects.add("Physics");
				subjects.add("Chemistry");
				subjects.add("Biology");
				subjects.add("English");
				m.addAttribute("subjects", subjects);
				page="enterPlan";
			}
			else
			{
				System.out.println("-------plan ID = ---------"+faculty.getId());
				Faculty obj = service.addFaculty(faculty);
				System.out.println("Return value="+obj);
				m.addAttribute("bean", obj);
				m.addAttribute("id", faculty.getId());
				page = "success";
			
			}
			return page;
	}
	@RequestMapping("getAllPlans.obj")
	public String getAllPlans(Model m)
	{
		String page="";
		
		return "";
	}
}
