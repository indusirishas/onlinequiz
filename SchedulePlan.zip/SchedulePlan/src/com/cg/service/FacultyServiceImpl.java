package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Faculty;
import com.cg.dao.IFacultyDao;
@Service("service")
public class FacultyServiceImpl implements IFacultyService {
	
	@Autowired
	IFacultyDao dao;
	public Faculty addFaculty(Faculty faculty)
	{
		return dao.addFaculty(faculty);
	}
}

