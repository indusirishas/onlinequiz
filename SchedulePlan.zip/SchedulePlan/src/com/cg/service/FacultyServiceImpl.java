package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Faculty;
import com.cg.dao.IFacultyDao;
@Service("service")
public class FacultyServiceImpl implements IFacultyService {
	
	@Autowired
	IFacultyDao dao;
	public Faculty addFaculty(Faculty faculty)
	{
		return dao.addFaculty(faculty);
	}
	
	public List<Faculty> getPlanById(Integer id) {
		return dao.getPlanById(id);
		
	}

	public List<Faculty> getAllPlans() {
		return dao.getAllPlans();
	}
}

