package com.cg.service;

import com.cg.bean.Faculty;

public interface IFacultyService {
	public Faculty addFaculty(Faculty faculty);
}
